/*
 * example.
 *
 */
#include <printk.h>

int main()
{
	printk("\n");
	printk("***********\n");
	printk("Hello VIVI.\n");
	printk("***********\n");

	return 0;
}
