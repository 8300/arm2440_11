#ifndef _VIVI_SETUP_H_
#define _VIVI_SETUP_H_

#define _LINUX_CONFIG_H

#include <asm/setup.h>

#endif

