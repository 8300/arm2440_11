#ifndef _VIVI_CTYPE_H_
#define _VIVI_CTYPE_H_

#define _LINUX_CONFIG_H

#include <linux/ctype.h>

#endif

