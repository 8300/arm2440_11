#ifndef _VIVI_ERRNO_H_
#define _VIVI_ERRNO_H_

#define _LINUX_CONFIG_H

#include <linux/errno.h>

#endif

